"""
api/server.py
Flask REST API + web dashboard for medical image anomaly detection.
"""

from __future__ import annotations
import os
import uuid
from pathlib import Path
from typing import List

from flask import (
    Flask, request, jsonify, render_template,
    send_from_directory, abort
)
from werkzeug.utils import secure_filename

from model.predictor import Predictor


UPLOAD_DIR = Path("data/uploads")
RESULTS_DIR = Path("data/results")
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

ALLOWED_EXTENSIONS = {"jpg", "jpeg", "png", "bmp", "tiff", "tif", "dcm"}
MAX_CONTENT_MB = 16


def _allowed(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def create_app(
    model_path: str = "models/best_model.pth",
    model_name: str = "efficientnet_b0",
    class_names: Optional[List[str]] = None,
) -> Flask:
    app = Flask(__name__, template_folder="templates", static_folder="static")
    app.config["MAX_CONTENT_LENGTH"] = MAX_CONTENT_MB * 1024 * 1024
    app.config["SECRET_KEY"] = "mad-dev-secret"

    predictor = Predictor(
        model_path=model_path,
        model_name=model_name,
        class_names=class_names or ["normal", "anomaly"],
    )

    # ── Pages ─────────────────────────────────────────────────────────────────

    @app.route("/")
    def index():
        # Load recent predictions from results dir
        recent = _load_recent_results(limit=20)
        return render_template("index.html", class_names=predictor.class_names, recent=recent)

    @app.route("/results/<path:filename>")
    def serve_result(filename):
        return send_from_directory(RESULTS_DIR, filename)

    @app.route("/uploads/<path:filename>")
    def serve_upload(filename):
        return send_from_directory(UPLOAD_DIR, filename)

    # ── API ───────────────────────────────────────────────────────────────────

    @app.route("/api/predict", methods=["POST"])
    def api_predict():
        """
        POST /api/predict
        Body: multipart/form-data with field 'image'
        Returns JSON with prediction result.
        """
        if "image" not in request.files:
            return jsonify({"error": "No image file provided"}), 400

        file = request.files["image"]
        if not file.filename or not _allowed(file.filename):
            return jsonify({"error": f"Unsupported file type. Allowed: {ALLOWED_EXTENSIONS}"}), 400

        # Save upload
        ext = file.filename.rsplit(".", 1)[1].lower()
        uid = uuid.uuid4().hex[:10]
        save_name = f"{uid}.{ext}"
        save_path = UPLOAD_DIR / save_name
        file.save(str(save_path))

        # Run prediction
        try:
            result = predictor.predict(str(save_path), save_heatmap=True)
            result["upload_url"] = f"/uploads/{save_name}"
            if result.get("heatmap_path"):
                hm = Path(result["heatmap_path"]).name
                result["heatmap_url"] = f"/results/{hm}"
            return jsonify(result)
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    @app.route("/api/health")
    def api_health():
        return jsonify({
            "status": "ok",
            "model": predictor.model.model_name,
            "classes": predictor.class_names,
            "device": predictor.device,
        })

    @app.route("/api/classes")
    def api_classes():
        return jsonify({"classes": predictor.class_names})

    return app


# ── Helpers ───────────────────────────────────────────────────────────────────

def _load_recent_results(limit: int = 20):
    """Scan results dir for recent heatmap images."""
    files = sorted(RESULTS_DIR.glob("gradcam_*.jpg"),
                   key=lambda p: p.stat().st_mtime, reverse=True)
    return [{"url": f"/results/{p.name}", "name": p.name} for p in files[:limit]]


# Allow import with optional type hint
from typing import Optional
