"""
utils/demo.py
Generates synthetic grayscale "medical-like" images so the project
runs and demonstrates predictions without a real dataset.
Uses numpy + PIL only (no torchvision dataset download needed).
"""

from __future__ import annotations
import random
import numpy as np
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter


DEMO_DIR = Path("data/demo_output")
DEMO_DIR.mkdir(parents=True, exist_ok=True)


def _make_normal_image(size: int = 224) -> Image.Image:
    """Simulate a 'normal' tissue scan: uniform texture, no bright spots."""
    rng = np.random.default_rng()
    base = rng.integers(60, 90, size=(size, size)).astype(np.uint8)
    noise = rng.integers(0, 20, size=(size, size)).astype(np.uint8)
    img_array = np.clip(base + noise, 0, 255).astype(np.uint8)
    img = Image.fromarray(img_array, mode="L").convert("RGB")
    img = img.filter(ImageFilter.GaussianBlur(radius=0.8))
    return img


def _make_anomaly_image(size: int = 224) -> Image.Image:
    """Simulate an 'anomaly' scan: bright irregular region."""
    img = _make_normal_image(size)
    draw = ImageDraw.Draw(img)
    # Add 1–3 bright irregular spots
    n_spots = random.randint(1, 3)
    for _ in range(n_spots):
        cx = random.randint(30, size - 30)
        cy = random.randint(30, size - 30)
        r = random.randint(12, 40)
        brightness = random.randint(170, 240)
        draw.ellipse(
            [(cx - r, cy - r), (cx + r, cy + r)],
            fill=(brightness, brightness // 2, brightness // 3),
        )
    img = img.filter(ImageFilter.GaussianBlur(radius=1.2))
    return img


def generate_sample_dataset(
    output_dir: str = "data/dataset",
    n_train: int = 60,
    n_val: int = 20,
    n_test: int = 20,
):
    """
    Generate a small synthetic dataset for training / testing.
    Structure:
        data/dataset/train/normal/   (n_train images)
        data/dataset/train/anomaly/  (n_train images)
        data/dataset/val/normal/     (n_val images)
        ...
    """
    root = Path(output_dir)
    splits = {"train": n_train, "val": n_val, "test": n_test}
    classes = {"normal": _make_normal_image, "anomaly": _make_anomaly_image}

    total = 0
    for split, n in splits.items():
        for cls, fn in classes.items():
            d = root / split / cls
            d.mkdir(parents=True, exist_ok=True)
            for i in range(n):
                img = fn()
                img.save(str(d / f"{cls}_{i:04d}.png"))
                total += 1

    print(f"[Demo] Generated {total} synthetic images under {root}/")
    print("       Run: python main.py train --data-dir data/dataset")
    return str(root)


def run_demo(
    model_path: str = "models/best_model.pth",
    class_names: list = None,
    n_images: int = 6,
):
    """
    Generate synthetic images, run predictions, save results.
    Works even without a trained model (shows random predictions).
    """
    class_names = class_names or ["normal", "anomaly"]
    from model.predictor import Predictor

    predictor = Predictor(model_path=model_path, class_names=class_names)

    print(f"\n[Demo] Running {n_images} demo predictions...\n")
    for i in range(n_images):
        is_anomaly = i % 2 == 1
        img = _make_anomaly_image() if is_anomaly else _make_normal_image()
        img_path = DEMO_DIR / f"demo_{i:02d}_{'anomaly' if is_anomaly else 'normal'}.png"
        img.save(str(img_path))

        result = predictor.predict(str(img_path), save_heatmap=True)
        print(
            f"  [{i+1}] {img_path.name:<45} "
            f"→ {result['label'].upper():<10} "
            f"({result['confidence']:.1f}%)"
        )
        if result["heatmap_path"]:
            print(f"       Heatmap: {result['heatmap_path']}")

    print(f"\n[Demo] Done! Results saved to data/results/")
    print("       Start the dashboard: python main.py dashboard")
