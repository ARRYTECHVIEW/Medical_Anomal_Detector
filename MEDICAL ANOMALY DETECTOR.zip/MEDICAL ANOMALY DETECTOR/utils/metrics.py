"""
utils/metrics.py
Evaluation metrics: accuracy, precision, recall, F1, ROC-AUC,
confusion matrix, and per-class reports.
"""

from __future__ import annotations
import json
from pathlib import Path
from typing import List, Dict

import numpy as np


def compute_metrics(
    y_true: List[int],
    y_pred: List[int],
    y_prob: List[List[float]],
    class_names: List[str],
) -> Dict:
    """
    Compute full evaluation metrics.
    y_true  — ground truth labels (list of ints)
    y_pred  — predicted labels
    y_prob  — predicted probabilities per class (list of lists)
    """
    y_true = np.array(y_true)
    y_pred = np.array(y_pred)
    y_prob = np.array(y_prob)
    n = len(class_names)

    # Accuracy
    accuracy = float(np.mean(y_true == y_pred)) * 100

    # Per-class precision, recall, F1
    per_class = {}
    for i, cls in enumerate(class_names):
        tp = int(np.sum((y_pred == i) & (y_true == i)))
        fp = int(np.sum((y_pred == i) & (y_true != i)))
        fn = int(np.sum((y_pred != i) & (y_true == i)))
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        recall    = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0
        per_class[cls] = {
            "precision": round(precision, 4),
            "recall":    round(recall, 4),
            "f1":        round(f1, 4),
            "support":   int(np.sum(y_true == i)),
        }

    # Macro F1
    macro_f1 = float(np.mean([per_class[c]["f1"] for c in class_names]))

    # Confusion matrix
    cm = np.zeros((n, n), dtype=int)
    for t, p in zip(y_true, y_pred):
        cm[t][p] += 1

    # ROC-AUC (binary only)
    roc_auc = None
    if n == 2 and y_prob.shape[1] >= 2:
        try:
            roc_auc = round(_roc_auc(y_true, y_prob[:, 1]), 4)
        except Exception:
            pass

    return {
        "accuracy": round(accuracy, 2),
        "macro_f1": round(macro_f1, 4),
        "roc_auc": roc_auc,
        "per_class": per_class,
        "confusion_matrix": cm.tolist(),
        "class_names": class_names,
    }


def print_report(metrics: Dict):
    print(f"\n{'='*55}")
    print(f"  Accuracy : {metrics['accuracy']:.2f}%")
    print(f"  Macro F1 : {metrics['macro_f1']:.4f}")
    if metrics["roc_auc"]:
        print(f"  ROC-AUC  : {metrics['roc_auc']:.4f}")
    print(f"\n  {'Class':<14} {'Precision':>10} {'Recall':>8} {'F1':>8} {'Support':>9}")
    print(f"  {'-'*51}")
    for cls, m in metrics["per_class"].items():
        print(f"  {cls:<14} {m['precision']:>10.4f} {m['recall']:>8.4f} "
              f"{m['f1']:>8.4f} {m['support']:>9}")
    print(f"\n  Confusion Matrix ({' / '.join(metrics['class_names'])}):")
    for row in metrics["confusion_matrix"]:
        print(f"    {row}")
    print(f"{'='*55}\n")


def save_metrics(metrics: Dict, path: str = "models/eval_metrics.json"):
    Path(path).parent.mkdir(exist_ok=True)
    with open(path, "w") as f:
        json.dump(metrics, f, indent=2)
    print(f"[Metrics] Saved to {path}")


def _roc_auc(y_true: np.ndarray, y_score: np.ndarray) -> float:
    """Simple trapezoidal ROC-AUC for binary classification."""
    pos = int(np.sum(y_true == 1))
    neg = int(np.sum(y_true == 0))
    if pos == 0 or neg == 0:
        return 0.0

    # Sort by descending score
    order = np.argsort(y_score)[::-1]
    y_sorted = y_true[order]

    tps = np.cumsum(y_sorted == 1)
    fps = np.cumsum(y_sorted == 0)

    tprs = np.concatenate([[0.0], tps / pos, [1.0]])
    fprs = np.concatenate([[0.0], fps / neg, [1.0]])

    # Ensure monotone for trapz (deduplicate fpr ties)
    return float(np.trapezoid(tprs, fprs))
