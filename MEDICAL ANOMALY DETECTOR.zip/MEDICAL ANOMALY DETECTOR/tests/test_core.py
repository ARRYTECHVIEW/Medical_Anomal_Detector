"""
tests/test_core.py
Unit tests — run with: pytest tests/ -v
No GPU or trained model required.
"""

import pytest
import numpy as np
from pathlib import Path
from PIL import Image
import tempfile


# ── Dataset tests ─────────────────────────────────────────────────────────────

def _make_fake_dataset(root: Path, classes=("normal", "anomaly"), n=4):
    for split in ("train", "val"):
        for cls in classes:
            d = root / split / cls
            d.mkdir(parents=True)
            for i in range(n):
                img = Image.fromarray(
                    np.random.randint(0, 255, (64, 64, 3), dtype=np.uint8)
                )
                img.save(str(d / f"{cls}_{i}.png"))


def test_dataset_loads():
    from model.dataset import MedicalImageDataset
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        _make_fake_dataset(root)
        ds = MedicalImageDataset(str(root), ["normal", "anomaly"], split="train")
        assert len(ds) == 8
        img, label = ds[0]
        assert img.shape == (3, 224, 224)
        assert label in (0, 1)


def test_dataset_class_counts():
    from model.dataset import MedicalImageDataset
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        _make_fake_dataset(root, n=5)
        ds = MedicalImageDataset(str(root), ["normal", "anomaly"], split="train")
        counts = ds.class_counts()
        assert counts["normal"] == 5
        assert counts["anomaly"] == 5


def test_empty_dataset_no_crash():
    from model.dataset import MedicalImageDataset
    with tempfile.TemporaryDirectory() as tmp:
        ds = MedicalImageDataset(tmp, ["normal", "anomaly"], split="train")
        assert len(ds) == 0


# ── Model architecture tests ──────────────────────────────────────────────────

def test_model_builds():
    from model.architecture import build_model
    import torch
    model = build_model("efficientnet_b0", num_classes=2, pretrained=False)
    assert model is not None
    x = torch.randn(2, 3, 224, 224)
    out = model(x)
    assert out.shape == (2, 2)


def test_model_forward_resnet():
    from model.architecture import build_model
    import torch
    model = build_model("resnet50", num_classes=3, pretrained=False)
    x = torch.randn(1, 3, 224, 224)
    out = model(x)
    assert out.shape == (1, 3)


def test_freeze_unfreeze():
    from model.architecture import build_model
    model = build_model("efficientnet_b0", num_classes=2, pretrained=False)
    model.freeze_backbone()
    frozen = [p for p in model.backbone.parameters() if not p.requires_grad]
    assert len(frozen) > 0
    model.unfreeze_backbone(layers_from_end=1)
    trainable = [p for p in model.backbone.parameters() if p.requires_grad]
    assert len(trainable) > 0


# ── Metrics tests ─────────────────────────────────────────────────────────────

def test_metrics_perfect():
    from utils.metrics import compute_metrics
    y_true = [0, 0, 1, 1]
    y_pred = [0, 0, 1, 1]
    y_prob = [[0.9, 0.1], [0.8, 0.2], [0.1, 0.9], [0.2, 0.8]]
    m = compute_metrics(y_true, y_pred, y_prob, ["normal", "anomaly"])
    assert m["accuracy"] == 100.0
    assert m["per_class"]["normal"]["f1"] == 1.0
    assert m["per_class"]["anomaly"]["f1"] == 1.0


def test_metrics_binary_roc():
    from utils.metrics import compute_metrics
    y_true = [0, 0, 1, 1, 0, 1]
    y_pred = [0, 1, 1, 1, 0, 0]
    y_prob = [[0.9,0.1],[0.4,0.6],[0.2,0.8],[0.1,0.9],[0.85,0.15],[0.55,0.45]]
    m = compute_metrics(y_true, y_pred, y_prob, ["normal", "anomaly"])
    assert m["roc_auc"] is not None
    assert 0.0 <= m["roc_auc"] <= 1.0


def test_confusion_matrix_shape():
    from utils.metrics import compute_metrics
    y_true = [0, 1, 2, 0, 1]
    y_pred = [0, 2, 2, 1, 1]
    y_prob = [[0.8,0.1,0.1],[0.1,0.2,0.7],[0.1,0.1,0.8],[0.3,0.5,0.2],[0.1,0.8,0.1]]
    m = compute_metrics(y_true, y_pred, y_prob, ["a", "b", "c"])
    assert len(m["confusion_matrix"]) == 3
    assert len(m["confusion_matrix"][0]) == 3


# ── Demo utility tests ────────────────────────────────────────────────────────

def test_demo_image_generation():
    from utils.demo import _make_normal_image, _make_anomaly_image
    img = _make_normal_image(64)
    assert img.size == (64, 64)
    assert img.mode == "RGB"
    img2 = _make_anomaly_image(64)
    assert img2.size == (64, 64)


def test_generate_sample_dataset():
    from utils.demo import generate_sample_dataset
    with tempfile.TemporaryDirectory() as tmp:
        generate_sample_dataset(tmp, n_train=4, n_val=2, n_test=2)
        assert (Path(tmp) / "train" / "normal").exists()
        assert len(list((Path(tmp) / "train" / "normal").glob("*.png"))) == 4
