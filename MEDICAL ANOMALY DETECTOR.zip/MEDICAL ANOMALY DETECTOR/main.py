"""
Medical Image Anomaly Detector
Entry point — train / predict / api / dashboard
"""

import argparse
import sys


def main():
    parser = argparse.ArgumentParser(
        description="Medical Image Anomaly Detector",
        formatter_class=argparse.RawTextHelpFormatter,
    )
    parser.add_argument(
        "mode",
        choices=["train", "predict", "api", "dashboard", "evaluate", "demo"],
        help=(
            "train      — train the model on a dataset\n"
            "predict    — run prediction on a single image\n"
            "api        — start the REST API server\n"
            "dashboard  — start the web dashboard\n"
            "evaluate   — evaluate model on test set\n"
            "demo       — generate demo predictions on sample images"
        ),
    )
    parser.add_argument("--image", help="Path to image (for predict mode)")
    parser.add_argument("--model", default="models/best_model.pth", help="Path to saved model weights")
    parser.add_argument("--data-dir", default="data/dataset", help="Dataset directory (for train/evaluate)")
    parser.add_argument("--epochs", type=int, default=30, help="Training epochs (default: 30)")
    parser.add_argument("--batch-size", type=int, default=32, help="Batch size (default: 32)")
    parser.add_argument("--lr", type=float, default=1e-4, help="Learning rate (default: 1e-4)")
    parser.add_argument("--backbone", default="efficientnet_b0",
                        choices=["efficientnet_b0", "resnet50", "densenet121"],
                        help="Model backbone (default: efficientnet_b0)")
    parser.add_argument("--host", default="127.0.0.1", help="Server host (default: 127.0.0.1)")
    parser.add_argument("--port", type=int, default=5000, help="Server port (default: 5000)")
    parser.add_argument("--classes", nargs="+", default=["normal", "anomaly"],
                        help="Class names (default: normal anomaly)")
    args = parser.parse_args()

    if args.mode == "train":
        from model.trainer import Trainer
        trainer = Trainer(
            data_dir=args.data_dir,
            model_name=args.backbone,
            num_classes=len(args.classes),
            class_names=args.classes,
            epochs=args.epochs,
            batch_size=args.batch_size,
            lr=args.lr,
        )
        trainer.train()

    elif args.mode == "predict":
        if not args.image:
            print("[ERROR] --image is required for predict mode.")
            sys.exit(1)
        from model.predictor import Predictor
        predictor = Predictor(model_path=args.model, class_names=args.classes)
        result = predictor.predict(args.image)
        print(f"\n{'='*50}")
        print(f"  Image     : {args.image}")
        print(f"  Prediction: {result['label'].upper()}")
        print(f"  Confidence: {result['confidence']:.1f}%")
        print(f"  All scores: {result['scores']}")
        print(f"{'='*50}\n")

    elif args.mode == "evaluate":
        from model.trainer import Trainer
        trainer = Trainer(data_dir=args.data_dir, model_name=args.backbone,
                          num_classes=len(args.classes), class_names=args.classes)
        trainer.evaluate(args.model)

    elif args.mode in ("api", "dashboard"):
        from api.server import create_app
        app = create_app(model_path=args.model, class_names=args.classes)
        mode_label = "API" if args.mode == "api" else "Dashboard"
        print(f"[INFO] Starting {mode_label} at http://{args.host}:{args.port}")
        app.run(host=args.host, port=args.port, debug=False)

    elif args.mode == "demo":
        from utils.demo import run_demo
        run_demo(model_path=args.model, class_names=args.classes)


if __name__ == "__main__":
    main()
