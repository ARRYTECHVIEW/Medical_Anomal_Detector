"""
model/architecture.py
CNN backbone + classifier head for medical image anomaly detection.
Supports EfficientNet-B0, ResNet-50, DenseNet-121.
"""

from __future__ import annotations
import torch
import torch.nn as nn
from typing import List


class AnomalyDetector(nn.Module):
    """
    Transfer-learning model for binary or multi-class anomaly detection.
    Backbone is frozen initially then unfrozen for fine-tuning.
    """

    def __init__(
        self,
        model_name: str = "efficientnet_b0",
        num_classes: int = 2,
        dropout: float = 0.3,
        pretrained: bool = True,
    ):
        super().__init__()
        self.model_name = model_name
        self.num_classes = num_classes
        self.backbone, in_features = self._build_backbone(model_name, pretrained)
        self.classifier = nn.Sequential(
            nn.Dropout(p=dropout),
            nn.Linear(in_features, 256),
            nn.ReLU(inplace=True),
            nn.Dropout(p=dropout / 2),
            nn.Linear(256, num_classes),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        features = self.backbone(x)
        return self.classifier(features)

    def freeze_backbone(self):
        """Freeze backbone parameters — train classifier head only."""
        for param in self.backbone.parameters():
            param.requires_grad = False

    def unfreeze_backbone(self, layers_from_end: int = 2):
        """Unfreeze last N layer groups for fine-tuning."""
        params = list(self.backbone.parameters())
        total = len(params)
        cutoff = max(0, total - layers_from_end * 20)
        for i, param in enumerate(params):
            param.requires_grad = i >= cutoff

    def get_feature_map(self, x: torch.Tensor) -> torch.Tensor:
        """Return intermediate feature maps for Grad-CAM."""
        return self._feature_maps

    # ── Internal ──────────────────────────────────────────────────────────────

    def _build_backbone(self, name: str, pretrained: bool):
        try:
            import torchvision.models as models
        except ImportError:
            raise ImportError("pip install torchvision")

        weights_arg = "DEFAULT" if pretrained else None

        if name == "efficientnet_b0":
            m = models.efficientnet_b0(weights=weights_arg)
            in_f = m.classifier[1].in_features
            m.classifier = nn.Identity()
            return m, in_f

        elif name == "resnet50":
            m = models.resnet50(weights=weights_arg)
            in_f = m.fc.in_features
            m.fc = nn.Identity()
            return m, in_f

        elif name == "densenet121":
            m = models.densenet121(weights=weights_arg)
            in_f = m.classifier.in_features
            m.classifier = nn.Identity()
            return m, in_f

        else:
            raise ValueError(f"Unknown backbone: {name}")


def build_model(
    model_name: str = "efficientnet_b0",
    num_classes: int = 2,
    pretrained: bool = True,
    device: str = "cpu",
) -> AnomalyDetector:
    model = AnomalyDetector(model_name=model_name, num_classes=num_classes, pretrained=pretrained)
    return model.to(device)


def load_model(
    path: str,
    model_name: str = "efficientnet_b0",
    num_classes: int = 2,
    device: str = "cpu",
) -> AnomalyDetector:
    model = AnomalyDetector(model_name=model_name, num_classes=num_classes, pretrained=False)
    state = torch.load(path, map_location=device)
    # Handle both raw state_dict and checkpoint dict
    if "model_state_dict" in state:
        model.load_state_dict(state["model_state_dict"])
    else:
        model.load_state_dict(state)
    model.to(device)
    model.eval()
    return model
