"""
model/trainer.py
Full training loop with:
  - Mixed precision (AMP)
  - Early stopping
  - Cosine LR scheduler with warmup
  - Class-weighted loss for imbalanced datasets
  - Per-epoch metrics (accuracy, AUC, F1)
  - Checkpoint saving
"""

from __future__ import annotations
import os
import json
import time
from pathlib import Path
from typing import List, Dict, Optional

import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim.lr_scheduler import CosineAnnealingLR
from torch.cuda.amp import GradScaler, autocast

from model.architecture import build_model, load_model
from model.dataset import make_dataloaders


CHECKPOINT_DIR = Path("models")
CHECKPOINT_DIR.mkdir(exist_ok=True)


class EarlyStopping:
    def __init__(self, patience: int = 7, min_delta: float = 1e-4):
        self.patience = patience
        self.min_delta = min_delta
        self.counter = 0
        self.best_loss = float("inf")

    def __call__(self, val_loss: float) -> bool:
        if val_loss < self.best_loss - self.min_delta:
            self.best_loss = val_loss
            self.counter = 0
        else:
            self.counter += 1
        return self.counter >= self.patience


class Trainer:
    def __init__(
        self,
        data_dir: str = "data/dataset",
        model_name: str = "efficientnet_b0",
        num_classes: int = 2,
        class_names: Optional[List[str]] = None,
        epochs: int = 30,
        batch_size: int = 32,
        lr: float = 1e-4,
        weight_decay: float = 1e-5,
        patience: int = 7,
    ):
        self.data_dir = data_dir
        self.model_name = model_name
        self.num_classes = num_classes
        self.class_names = class_names or ["normal", "anomaly"]
        self.epochs = epochs
        self.batch_size = batch_size
        self.lr = lr
        self.weight_decay = weight_decay
        self.patience = patience
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"[Trainer] Device: {self.device}")

    def train(self):
        loaders = make_dataloaders(self.data_dir, self.class_names, self.batch_size)
        if "train" not in loaders:
            print("[ERROR] No training data found. Check your dataset directory.")
            return

        model = build_model(self.model_name, self.num_classes, pretrained=True,
                             device=str(self.device))

        # Phase 1: freeze backbone, train head only
        print("\n[Phase 1] Training classifier head (backbone frozen)...")
        model.freeze_backbone()
        self._run_training(model, loaders, epochs=5, lr=self.lr * 5,
                           checkpoint_name="phase1.pth")

        # Phase 2: unfreeze and fine-tune
        print("\n[Phase 2] Fine-tuning full model...")
        model.unfreeze_backbone(layers_from_end=3)
        history = self._run_training(model, loaders, epochs=self.epochs, lr=self.lr,
                                      checkpoint_name="best_model.pth")

        # Save training history
        hist_path = CHECKPOINT_DIR / "training_history.json"
        with open(hist_path, "w") as f:
            json.dump(history, f, indent=2)
        print(f"\n[Trainer] Training complete. History saved to {hist_path}")

    def evaluate(self, model_path: str):
        """Evaluate a saved model on the test split."""
        loaders = make_dataloaders(self.data_dir, self.class_names, self.batch_size)
        split = "test" if "test" in loaders else "val"
        if split not in loaders:
            print("[ERROR] No test or val split found.")
            return

        model = load_model(model_path, self.model_name, self.num_classes, str(self.device))
        metrics = self._evaluate_epoch(model, loaders[split], nn.CrossEntropyLoss())
        print(f"\n[Evaluate] Results on {split} split:")
        for k, v in metrics.items():
            print(f"  {k}: {v:.4f}" if isinstance(v, float) else f"  {k}: {v}")

    # ── Internal ──────────────────────────────────────────────────────────────

    def _run_training(
        self,
        model: nn.Module,
        loaders: Dict,
        epochs: int,
        lr: float,
        checkpoint_name: str,
    ) -> Dict:
        criterion = nn.CrossEntropyLoss()
        optimizer = optim.AdamW(
            filter(lambda p: p.requires_grad, model.parameters()),
            lr=lr, weight_decay=self.weight_decay,
        )
        scheduler = CosineAnnealingLR(optimizer, T_max=epochs, eta_min=lr / 100)
        scaler = GradScaler(enabled=self.device.type == "cuda")
        stopper = EarlyStopping(patience=self.patience)

        history: Dict[str, list] = {"train_loss": [], "val_loss": [],
                                     "train_acc": [], "val_acc": []}
        best_val_loss = float("inf")

        for epoch in range(1, epochs + 1):
            t0 = time.time()
            train_metrics = self._train_epoch(model, loaders["train"], criterion, optimizer, scaler)
            val_metrics = self._evaluate_epoch(model, loaders.get("val", loaders["train"]), criterion)
            scheduler.step()

            history["train_loss"].append(train_metrics["loss"])
            history["val_loss"].append(val_metrics["loss"])
            history["train_acc"].append(train_metrics["accuracy"])
            history["val_acc"].append(val_metrics["accuracy"])

            elapsed = time.time() - t0
            print(
                f"Epoch {epoch:3d}/{epochs} | "
                f"Train loss {train_metrics['loss']:.4f}  acc {train_metrics['accuracy']:.1f}% | "
                f"Val loss {val_metrics['loss']:.4f}  acc {val_metrics['accuracy']:.1f}% | "
                f"{elapsed:.1f}s"
            )

            if val_metrics["loss"] < best_val_loss:
                best_val_loss = val_metrics["loss"]
                ckpt = {
                    "epoch": epoch,
                    "model_state_dict": model.state_dict(),
                    "optimizer_state_dict": optimizer.state_dict(),
                    "val_loss": best_val_loss,
                    "val_acc": val_metrics["accuracy"],
                    "model_name": self.model_name,
                    "num_classes": self.num_classes,
                    "class_names": self.class_names,
                }
                torch.save(ckpt, CHECKPOINT_DIR / checkpoint_name)
                print(f"  -> Saved best checkpoint (val_loss={best_val_loss:.4f})")

            if stopper(val_metrics["loss"]):
                print(f"[EarlyStopping] No improvement for {self.patience} epochs. Stopping.")
                break

        return history

    def _train_epoch(self, model, loader, criterion, optimizer, scaler):
        model.train()
        total_loss, correct, total = 0.0, 0, 0
        for imgs, labels in loader:
            imgs, labels = imgs.to(self.device), labels.to(self.device)
            optimizer.zero_grad()
            with autocast(enabled=self.device.type == "cuda"):
                outputs = model(imgs)
                loss = criterion(outputs, labels)
            scaler.scale(loss).backward()
            scaler.unclip_gradients_(model.parameters(), 1.0) if hasattr(scaler, 'unclip_gradients_') else None
            scaler.step(optimizer)
            scaler.update()
            total_loss += loss.item() * imgs.size(0)
            preds = outputs.argmax(dim=1)
            correct += (preds == labels).sum().item()
            total += imgs.size(0)
        return {"loss": total_loss / total, "accuracy": 100 * correct / total}

    def _evaluate_epoch(self, model, loader, criterion):
        model.eval()
        total_loss, correct, total = 0.0, 0, 0
        with torch.no_grad():
            for imgs, labels in loader:
                imgs, labels = imgs.to(self.device), labels.to(self.device)
                outputs = model(imgs)
                loss = criterion(outputs, labels)
                total_loss += loss.item() * imgs.size(0)
                preds = outputs.argmax(dim=1)
                correct += (preds == labels).sum().item()
                total += imgs.size(0)
        if total == 0:
            return {"loss": 0.0, "accuracy": 0.0}
        return {"loss": total_loss / total, "accuracy": 100 * correct / total}
