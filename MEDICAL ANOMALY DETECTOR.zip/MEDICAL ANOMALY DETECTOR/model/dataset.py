"""
model/dataset.py
Dataset, transforms, and DataLoader factory for medical images.

Expected folder structure:
  data/dataset/
    train/
      normal/    *.jpg / *.png
      anomaly/   *.jpg / *.png
    val/
      normal/
      anomaly/
    test/        (optional)
      normal/
      anomaly/
"""

from __future__ import annotations
import os
from pathlib import Path
from typing import List, Tuple, Dict, Optional

from PIL import Image
import torch
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms


# ── Image size ────────────────────────────────────────────────────────────────
IMG_SIZE = 224

# ── ImageNet normalisation (used by all pretrained backbones) ─────────────────
IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD  = [0.229, 0.224, 0.225]


def get_transforms(split: str = "train") -> transforms.Compose:
    """Return augmentation pipeline appropriate for train / val / test."""
    if split == "train":
        return transforms.Compose([
            transforms.Resize((IMG_SIZE + 32, IMG_SIZE + 32)),
            transforms.RandomCrop(IMG_SIZE),
            transforms.RandomHorizontalFlip(),
            transforms.RandomVerticalFlip(),
            transforms.RandomRotation(15),
            transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.1),
            transforms.RandomAffine(degrees=0, translate=(0.05, 0.05)),
            transforms.ToTensor(),
            transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
        ])
    else:
        return transforms.Compose([
            transforms.Resize((IMG_SIZE, IMG_SIZE)),
            transforms.ToTensor(),
            transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
        ])


class MedicalImageDataset(Dataset):
    """
    Simple ImageFolder-style dataset with explicit class list.
    Handles grayscale images by converting to RGB.
    """

    def __init__(
        self,
        root: str,
        class_names: List[str],
        split: str = "train",
        transform: Optional[transforms.Compose] = None,
    ):
        self.root = Path(root) / split
        self.class_names = class_names
        self.class_to_idx: Dict[str, int] = {c: i for i, c in enumerate(class_names)}
        self.transform = transform or get_transforms(split)
        self.samples: List[Tuple[Path, int]] = []
        self._load_samples()

    def _load_samples(self):
        exts = {".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".tif"}
        for cls in self.class_names:
            cls_dir = self.root / cls
            if not cls_dir.exists():
                continue
            label = self.class_to_idx[cls]
            for p in cls_dir.iterdir():
                if p.suffix.lower() in exts:
                    self.samples.append((p, label))
        if not self.samples:
            print(f"[WARN] No images found under {self.root}. "
                  "Run 'python main.py demo' to generate sample images.")

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx: int):
        path, label = self.samples[idx]
        img = Image.open(path).convert("RGB")
        tensor = self.transform(img)
        return tensor, label

    def class_counts(self) -> Dict[str, int]:
        counts = {c: 0 for c in self.class_names}
        for _, label in self.samples:
            counts[self.class_names[label]] += 1
        return counts


def make_dataloaders(
    data_dir: str,
    class_names: List[str],
    batch_size: int = 32,
    num_workers: int = 2,
) -> Dict[str, DataLoader]:
    """Return train / val / test DataLoaders."""
    loaders = {}
    for split in ("train", "val", "test"):
        split_path = Path(data_dir) / split
        if not split_path.exists():
            continue
        ds = MedicalImageDataset(data_dir, class_names, split=split)
        shuffle = split == "train"
        loaders[split] = DataLoader(
            ds,
            batch_size=batch_size,
            shuffle=shuffle,
            num_workers=num_workers,
            pin_memory=torch.cuda.is_available(),
        )
        counts = ds.class_counts()
        print(f"[Dataset] {split:5s} → {len(ds):4d} images | {counts}")
    return loaders
