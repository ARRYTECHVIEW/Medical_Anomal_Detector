"""
model/predictor.py
Inference engine with Grad-CAM visualisation.

Grad-CAM highlights WHICH regions of the image triggered the anomaly prediction,
giving doctors a visual explanation (explainable AI).
"""

from __future__ import annotations
import os
import uuid
from pathlib import Path
from typing import List, Dict, Any, Optional

import numpy as np
from PIL import Image

import torch
import torch.nn.functional as F

from model.architecture import load_model, AnomalyDetector
from model.dataset import get_transforms, IMG_SIZE


RESULTS_DIR = Path("data/results")
RESULTS_DIR.mkdir(parents=True, exist_ok=True)


class GradCAM:
    """
    Gradient-weighted Class Activation Map.
    Attaches hooks to the last convolutional layer of the backbone.
    """

    def __init__(self, model: AnomalyDetector):
        self.model = model
        self.gradients: Optional[torch.Tensor] = None
        self.activations: Optional[torch.Tensor] = None
        self._hook_layer()

    def _hook_layer(self):
        # Find the last conv layer dynamically
        target_layer = self._find_last_conv(self.model.backbone)
        if target_layer is None:
            return
        target_layer.register_forward_hook(self._save_activation)
        target_layer.register_backward_hook(self._save_gradient)

    def _find_last_conv(self, module: torch.nn.Module):
        last_conv = None
        for m in module.modules():
            if isinstance(m, torch.nn.Conv2d):
                last_conv = m
        return last_conv

    def _save_activation(self, module, input, output):
        self.activations = output.detach()

    def _save_gradient(self, module, grad_input, grad_output):
        self.gradients = grad_output[0].detach()

    def generate(self, input_tensor: torch.Tensor, class_idx: int) -> np.ndarray:
        """Return a heatmap numpy array [0..1] same spatial size as input."""
        self.model.eval()
        output = self.model(input_tensor)
        self.model.zero_grad()
        one_hot = torch.zeros_like(output)
        one_hot[0][class_idx] = 1.0
        output.backward(gradient=one_hot)

        if self.gradients is None or self.activations is None:
            return np.zeros((IMG_SIZE, IMG_SIZE))

        weights = self.gradients.mean(dim=(2, 3), keepdim=True)
        cam = (weights * self.activations).sum(dim=1, keepdim=True)
        cam = F.relu(cam)
        cam = F.interpolate(cam, size=(IMG_SIZE, IMG_SIZE), mode="bilinear", align_corners=False)
        cam = cam.squeeze().cpu().numpy()
        cam = (cam - cam.min()) / (cam.max() - cam.min() + 1e-8)
        return cam


class Predictor:
    def __init__(
        self,
        model_path: str = "models/best_model.pth",
        model_name: str = "efficientnet_b0",
        class_names: Optional[List[str]] = None,
        device: str = "cpu",
    ):
        self.class_names = class_names or ["normal", "anomaly"]
        self.device = device
        self.transform = get_transforms("val")

        if Path(model_path).exists():
            self.model = load_model(model_path, model_name, len(self.class_names), device)
        else:
            print(f"[WARN] Model not found at {model_path}. Using untrained model for demo.")
            from model.architecture import build_model
            self.model = build_model(model_name, len(self.class_names), pretrained=False)
            self.model.eval()

        self.grad_cam = GradCAM(self.model)

    def predict(self, image_path: str, save_heatmap: bool = True) -> Dict[str, Any]:
        """
        Run inference on a single image.
        Returns dict with label, confidence, scores, heatmap_path.
        """
        img = Image.open(image_path).convert("RGB")
        tensor = self.transform(img).unsqueeze(0).to(self.device)
        tensor.requires_grad_(True)

        self.model.eval()
        with torch.no_grad():
            logits = self.model(tensor)
            probs = F.softmax(logits, dim=1).squeeze()

        scores = {cls: round(float(probs[i]) * 100, 2)
                  for i, cls in enumerate(self.class_names)}
        pred_idx = int(probs.argmax())
        label = self.class_names[pred_idx]
        confidence = round(float(probs[pred_idx]) * 100, 2)

        # Generate Grad-CAM heatmap
        heatmap_path = None
        if save_heatmap:
            tensor_grad = self.transform(img).unsqueeze(0).to(self.device)
            tensor_grad.requires_grad_(True)
            cam = self.grad_cam.generate(tensor_grad, pred_idx)
            heatmap_path = self._overlay_heatmap(img, cam, label, confidence)

        return {
            "label": label,
            "confidence": confidence,
            "scores": scores,
            "heatmap_path": str(heatmap_path) if heatmap_path else None,
            "image_path": image_path,
            "prediction_id": str(uuid.uuid4())[:8],
        }

    def _overlay_heatmap(
        self, original: Image.Image, cam: np.ndarray, label: str, confidence: float
    ) -> Path:
        """Overlay Grad-CAM heatmap on original image and save."""
        import cv2

        orig_np = np.array(original.resize((IMG_SIZE, IMG_SIZE)))
        heatmap = cv2.applyColorMap(np.uint8(255 * cam), cv2.COLORMAP_JET)
        heatmap_rgb = cv2.cvtColor(heatmap, cv2.COLOR_BGR2RGB)
        overlay = cv2.addWeighted(orig_np, 0.6, heatmap_rgb, 0.4, 0)

        # Add label text
        color = (255, 80, 80) if label != "normal" else (80, 220, 80)
        cv2.putText(overlay, f"{label.upper()} {confidence:.0f}%",
                    (8, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.65, color, 2)

        out_path = RESULTS_DIR / f"gradcam_{uuid.uuid4().hex[:8]}.jpg"
        cv2.imwrite(str(out_path), cv2.cvtColor(overlay, cv2.COLOR_RGB2BGR))
        return out_path
